//
//  DEBottomDialog.m
//  ldemo
//
//  Created by njw on 2020/3/28.
//  Copyright © 2020 njw. All rights reserved.
//

#import "DEBottomDialog.h"
#import "DEDialogController.h"

#define kExpectationHeight 230.f

@interface DEBottomDialog ()
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UIScrollView *contentView;
@property (nonatomic, weak) DEDialogController *backViewController;
@property (nonatomic, strong) UIButton *closeBtn;
@end

@implementation DEBottomDialog

+ (instancetype)showBusinessExpectations:(NSString *)expectation {
    DEBottomDialog *bottomDialog = [[DEBottomDialog alloc] initWithFrame:CGRectZero];
    bottomDialog.titleLabel.text = @"商家期望";
    bottomDialog.detailLabel.text = expectation;
    return bottomDialog;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        
        [self setUpUI];
        
        [self setSubViews];
    }
    return self;
}

- (void)setUpUI {
    [self addSubview:self.headerView];
    [self.headerView addSubview:self.titleLabel];
    [self.headerView addSubview:self.closeBtn];
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.detailLabel];
        
    DEDialogController *modalViewController = [[DEDialogController alloc] init];
    modalViewController.contentView = self;
    self.backViewController = modalViewController;
    __weak typeof(modalViewController) weakVc = modalViewController;
    if ([modalViewController respondsToSelector:@selector(handleDimmingViewTapGestureRecognizer:)]) {
        [self.closeBtn addTarget:weakVc action:@selector(handleDimmingViewTapGestureRecognizer:) forControlEvents:UIControlEventTouchUpInside];
    }
    __weak typeof(self) WEAK = self;
    modalViewController.layoutBlock = ^(CGRect containerBounds, CGFloat keyboardHeight, CGRect contentViewDefaultFrame) {
        containerBounds.origin.y += containerBounds.size.height - kExpectationHeight;
        containerBounds.size.height = kExpectationHeight;
        WEAK.frameApplyTransform = containerBounds;
        WEAK.contentView.frame = CGRectMake(0, 55, CGRectGetWidth(containerBounds), CGRectGetHeight(containerBounds)-55);
        WEAK.headerView.frame = CGRectMake(0, 0, containerBounds.size.width, 55);
        
    };
    [modalViewController showWithAnimated:YES completion:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [DEUIHelper setView:self Radii:CGSizeMake(12, 12) RoundingCorners:UIRectCornerTopLeft |UIRectCornerTopRight];
    self.closeBtn.frame = CGRectMake(CGRectGetWidth(self.frame)-15-80, 15, 80, 30);
    self.titleLabel.frame = CGRectMake(0, 0, 80, 30);
    self.titleLabel.center = self.headerView.center;
    self.detailLabel.frame = CGRectMake(15, 15, CGRectGetWidth(self.contentView.frame) - 30, 80);
    
}

- (void)setSubViews {
    
}

- (UIView *)headerView {
    if (nil == _headerView) {
        _headerView = [[UIView alloc] initWithFrame:CGRectZero];
        _headerView.backgroundColor = UIColorMakeWithRGBA(255, 255, 255, 1);
    }
    return _headerView;
}

- (UILabel *)titleLabel {
    if (nil == _titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _titleLabel.textColor = [UIColor blackColor];
    }
    return _titleLabel;
}

- (UIScrollView *)contentView {
    if (nil == _contentView) {
        _contentView = [[UIScrollView alloc] initWithFrame:CGRectZero];
        _contentView.alwaysBounceVertical = NO;
    }
    return _contentView;
}

- (UIButton *)closeBtn {
    if (nil == _closeBtn) {
        _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [_closeBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }
    return _closeBtn;
}

- (UILabel *)detailLabel {
    if (nil == _detailLabel) {
        _detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _detailLabel.textColor = [UIColor blackColor];
        _detailLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _detailLabel.numberOfLines = 0;
        _detailLabel.lineBreakMode = NSLineBreakByWordWrapping | NSLineBreakByCharWrapping;
//        _detailLabel.lineBreakMode = NSLineBreakByWordWrapping;
    }
    return _detailLabel;
}

- (void)dealloc {
    self.backViewController = nil;
}

@end
