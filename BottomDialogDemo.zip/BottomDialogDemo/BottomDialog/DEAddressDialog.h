//
//  DEAddressDialog.h
//  BottomDialog
//
//  Created by njw on 2020/3/28.
//  Copyright © 2020 njw. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void (^addressImgsBlk)(id vc, NSUInteger index, NSArray *images);

@interface DEAddressDialog : UIView
+ (instancetype)showAddressDetail:(NSString *)aDetail withImages:(NSArray *)imagesNames clickImageBlock:(addressImgsBlk) block;
@end

NS_ASSUME_NONNULL_END
