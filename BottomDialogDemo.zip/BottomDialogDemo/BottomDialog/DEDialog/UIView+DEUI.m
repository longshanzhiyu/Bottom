//
//  UIView+DEUI.m
//  ldemo
//
//  Created by njw on 2020/3/27.
//  Copyright © 2020 njw. All rights reserved.
//

#import "UIView+DEUI.h"
#import "DEUIHelper.h"
#import "UIViewController+DEUI.h"

@implementation UIView (DEUI)
- (void)setFrameApplyTransform:(CGRect)frameApplyTransform {
    self.frame = CGRectApplyAffineTransformWithAnchorPoint(frameApplyTransform, self.transform, self.layer.anchorPoint);
}

- (CGRect)frameApplyTransform {
    return self.frame;
}
@end

@implementation UIView (DEUI_ViewController)

DEUISynthesizeBOOLProperty(isControllerRootView, setIsControllerRootView)

- (BOOL)visible {
    if (self.hidden || self.alpha <= 0.01) {
        return NO;
    }
    if (self.window) {
        return YES;
    }
    if ([self isKindOfClass:UIWindow.class]) {
        if (@available(iOS 13.0, *)) {
            return !!((UIWindow *)self).windowScene;
        } else {
            return YES;
        }
    }
    UIViewController *viewController = self.viewController;
    return viewController.visibleState >= DEUIViewControllerWillAppear && viewController.visibleState < DEUIViewControllerWillDisappear;
}

static char kAssociatedObjectKey_viewController;
- (void)setViewController:(__kindof UIViewController * _Nullable)viewController {
    DEUIHelper *weakContainer = objc_getAssociatedObject(self, &kAssociatedObjectKey_viewController);
    if (!weakContainer) {
        weakContainer = [DEUIHelper new];
    }
    weakContainer.object = viewController;
    objc_setAssociatedObject(self, &kAssociatedObjectKey_viewController, weakContainer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    self.isControllerRootView = !!viewController;
}

- (__kindof UIViewController *)viewController {
    if (self.isControllerRootView) {
        return (__kindof UIViewController *)((DEUIHelper *)objc_getAssociatedObject(self, &kAssociatedObjectKey_viewController)).object;
    }
    return self.superview.viewController;
}

@end
