//
//  UIViewController+DEUI.m
//  ldemo
//
//  Created by njw on 2020/3/28.
//  Copyright © 2020 njw. All rights reserved.
//

#import "UIViewController+DEUI.h"
#import "DEUIHelper.h"
#import "UIView+DEUI.h"

@implementation UIViewController (DEUI)
DEUISynthesizeIdCopyProperty(visibleStateDidChangeBlock, setVisibleStateDidChangeBlock)

static char kAssociatedObjectKey_visibleState;
- (void)setVisibleState:(DEUIViewControllerVisibleState)visibleState {
    BOOL valueChanged = self.visibleState != visibleState;
    objc_setAssociatedObject(self, &kAssociatedObjectKey_visibleState, @(visibleState), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (valueChanged && self.visibleStateDidChangeBlock) {
        self.visibleStateDidChangeBlock(self, visibleState);
    }
}

- (DEUIViewControllerVisibleState)visibleState {
    return [((NSNumber *)objc_getAssociatedObject(self, &kAssociatedObjectKey_visibleState)) unsignedIntegerValue];
}

- (UIViewController *)previousViewController {
    if (self.navigationController.viewControllers && self.navigationController.viewControllers.count > 1 && self.navigationController.topViewController == self) {
        NSUInteger count = self.navigationController.viewControllers.count;
        return (UIViewController *)[self.navigationController.viewControllers objectAtIndex:count - 2];
    }
    return nil;
}

- (BOOL)isPresented {
    UIViewController *viewController = self;
    if (self.navigationController) {

        viewController = self.navigationController;
    }
    BOOL result = viewController.presentingViewController.presentedViewController == viewController;
    return result;
}

- (UIViewController *)visibleViewControllerIfExist {

    if (self.presentedViewController) {
        return [self.presentedViewController visibleViewControllerIfExist];
    }

    if ([self isKindOfClass:[UINavigationController class]]) {
        return [((UINavigationController *)self).visibleViewController visibleViewControllerIfExist];
    }

    if ([self isKindOfClass:[UITabBarController class]]) {
        return [((UITabBarController *)self).selectedViewController visibleViewControllerIfExist];
    }

    if ([self isViewLoadedAndVisible]) {
        return self;
    } else {

        return nil;
    }
}

- (BOOL)isViewLoadedAndVisible {
    return self.isViewLoaded && self.view.visible;
}
@end


