//
//  DEAddressDialog.m
//  BottomDialog
//
//  Created by njw on 2020/3/28.
//  Copyright © 2020 njw. All rights reserved.
//

#import "DEAddressDialog.h"
#import "DEDialogController.h"

#define kAddrDetail_Height 559.f
#define kAddrImg_Height 190.f

@interface DEAddressImageCell : UITableViewCell

@end

@implementation DEAddressImageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor lightGrayColor];
    }
    return self;
}

- (void)setFrame:(CGRect)frame {
    frame.origin.x += 15;
    frame.origin.y += 5;
    frame.size.width -= 30;
    frame.size.height -= 10;
    [super setFrame:frame];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [DEUIHelper setView:self Radii:CGSizeMake(8, 8) RoundingCorners:UIRectCornerAllCorners];
}

@end

@interface DEAddressDialog () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, weak) DEDialogController *backViewController;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, strong) NSArray *images;
@property (nonatomic, copy) addressImgsBlk block;
@end

@implementation DEAddressDialog

+ (instancetype)showAddressDetail:(NSString *)aDetail withImages:(NSArray *)imagesNames clickImageBlock:(addressImgsBlk) block {
    DEAddressDialog *bottomDialog = [[DEAddressDialog alloc] initWithFrame:CGRectZero];
    bottomDialog.titleLabel.text = @"地址详情";
    bottomDialog.detailLabel.text = aDetail;
    bottomDialog.images = [NSArray arrayWithArray:imagesNames];
    bottomDialog.block = block;
    return bottomDialog;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        
        [self setUpUI];
        
//        [self setSubViews];
    }
    return self;
}

- (void)setUpUI {
    [self addSubview:self.headerView];
    [self.headerView addSubview:self.titleLabel];
    [self.headerView addSubview:self.closeBtn];
    [self addSubview:self.contentView];
    [self.headerView addSubview:self.detailLabel];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableHeaderView = self.contentView;
    [self.contentView addSubview:self.detailLabel];
        
    DEDialogController *modalViewController = [[DEDialogController alloc] init];
    modalViewController.contentView = self;
    self.backViewController = modalViewController;
    __weak typeof(modalViewController) weakVc = modalViewController;
    if ([modalViewController respondsToSelector:@selector(handleDimmingViewTapGestureRecognizer:)]) {
        [self.closeBtn addTarget:weakVc action:@selector(handleDimmingViewTapGestureRecognizer:) forControlEvents:UIControlEventTouchUpInside];
    }
    __weak typeof(self) WEAK = self;
    modalViewController.layoutBlock = ^(CGRect containerBounds, CGFloat keyboardHeight, CGRect contentViewDefaultFrame) {
        containerBounds.origin.y += containerBounds.size.height - kAddrDetail_Height;
        containerBounds.size.height = kAddrDetail_Height;
        WEAK.frameApplyTransform = containerBounds;
//        WEAK.contentView.frame = CGRectMake(0, 55, CGRectGetWidth(containerBounds), CGRectGetHeight(containerBounds)-55);
        WEAK.headerView.frame = CGRectMake(0, 0, containerBounds.size.width, 55);
        WEAK.contentView.frame = CGRectMake(0, 0, CGRectGetWidth(containerBounds), 80);
    };
    [modalViewController showWithAnimated:YES completion:nil];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [DEUIHelper setView:self Radii:CGSizeMake(12, 12) RoundingCorners:UIRectCornerTopLeft |UIRectCornerTopRight];
    self.closeBtn.frame = CGRectMake(CGRectGetWidth(self.frame)-15-80, 15, 80, 30);
    self.titleLabel.frame = CGRectMake(0, 0, 80, 30);
    self.titleLabel.center = self.headerView.center;
    self.tableView.frame = CGRectMake(0, CGRectGetMaxY(self.headerView.frame), self.frame.size.width, self.frame.size.height - CGRectGetHeight(self.headerView.frame));
    self.detailLabel.frame = CGRectMake(15, 15, CGRectGetWidth(self.contentView.frame) - 30, CGRectGetHeight(self.contentView.frame) - 15);
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.001;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.images.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"addressDetailImage";
    DEAddressImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (nil == cell) {
        cell = [[DEAddressImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kAddrImg_Height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.block) {
        self.block(self.backViewController, indexPath.row, self.images);
    }
}


- (UIView *)headerView {
    if (nil == _headerView) {
        _headerView = [[UIView alloc] initWithFrame:CGRectZero];
        _headerView.backgroundColor = UIColorMakeWithRGBA(255, 255, 255, 1);
    }
    return _headerView;
}

- (UILabel *)titleLabel {
    if (nil == _titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _titleLabel.textColor = [UIColor blackColor];
    }
    return _titleLabel;
}

- (UITableView *)tableView {
    if (nil == _tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.alwaysBounceVertical = NO;
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.contentInset = UIEdgeInsetsMake(5, 0, 5, 0);
    }
    return _tableView;
}

- (UIButton *)closeBtn {
    if (nil == _closeBtn) {
        _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [_closeBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }
    return _closeBtn;
}

- (UILabel *)detailLabel {
    if (nil == _detailLabel) {
        _detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _detailLabel.textColor = [UIColor blackColor];
        _detailLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _detailLabel.numberOfLines = 0;
        _detailLabel.lineBreakMode = NSLineBreakByWordWrapping | NSLineBreakByCharWrapping;
//        _detailLabel.lineBreakMode = NSLineBreakByWordWrapping;
    }
    return _detailLabel;
}

- (UIView *)contentView {
    if (nil == _contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectZero];
        _contentView.backgroundColor = [UIColor whiteColor];
    }
    return _contentView;
}

- (void)dealloc {
    self.backViewController = nil;
}

@end
