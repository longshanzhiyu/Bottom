//
//  SceneDelegate.h
//  ldemo
//
//  Created by njw on 2020/3/27.
//  Copyright © 2020 njw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

