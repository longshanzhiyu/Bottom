//
//  ViewController.m
//  ldemo
//
//  Created by njw on 2020/3/27.
//  Copyright © 2020 njw. All rights reserved.
//

#import "ViewController.h"
#import "AViewController.h"
#define UIColorTheme10 UIColorMake(39, 192, 243) // Dark
#define CodeFontMake(_pointSize) [UIFont fontWithName:@"Menlo" size:_pointSize]
#define CodeAttributes(_fontSize) @{NSFontAttributeName: CodeFontMake(_fontSize), NSForegroundColorAttributeName: UIColorTheme10}
#define UIColorGray3 UIColorMake(93, 100, 110)
const CGFloat QMUIViewSelfSizingHeight = INFINITY;

//#import "QMUIModalPresentationViewController.h"
#import "DEDialogController.h"
#import "DEBottomDialog.h"
#import "DEAddressDialog.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray *data;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UITableView *tableview = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    [self.view addSubview:tableview];
    tableview.delegate = self;
    tableview.dataSource = self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"Demo";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    cell.textLabel.text = [self.data objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
            [self handleLayoutBlockAndAnimation];
            break;
        
        case 1:
            [self showAddressDetail];
            break;
            
        default:
            break;
    }
    
}

- (void)showAddressDetail {
    [DEAddressDialog showAddressDetail:@"法律的减肥啦减肥的镂空设计了看见啦睡觉的撒老骥伏枥卡绝对是雷锋精神啦放假啦都是克己复礼都开始减肥了快结束了肯德基费拉达斯克己复礼看见阿莱克斯江东父老看手机啊浪费空间的撒了" withImages:@[@"abc", @"bcd"] clickImageBlock:^(id  _Nonnull vc, NSUInteger index, NSArray * _Nonnull images) {
        if ([vc isKindOfClass:[UIViewController class]]) {
            [((UIViewController *)vc ) presentViewController:[AViewController new] animated:YES completion:^{
                
            }];
        }
    }];
}

- (NSMutableArray *)data {
    if (!_data) {
        _data = [NSMutableArray new];
        [_data addObject:@"layoutBlock"];
        [_data addObject:@"detailBlock"];
    }
    return _data;
}

#pragma mark - Handles
- (void)handleLayoutBlockAndAnimation {
    [DEBottomDialog showBusinessExpectations:@"利用layoutBlock可以自定义浮层的布局，注意此时contentViewMargins、maximumContentViewWidth属性均无效，如果需要实现外间距、最大宽高的保护，请自行计算。\n另外搭配showingAnimation、hidingAnimation也可制作自己的显示/隐藏动画，例如这个例子里实现了一个从底部升起的面板，升起后停靠在容器底端，你可以试着旋转设备，会发现依然能正确布局。"];
    return;
    UIScrollView *contentView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 300, 250)];
    contentView.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:1];
    contentView.layer.cornerRadius = 6;
    contentView.alwaysBounceVertical = NO;
    
    UILabel *label = [[UILabel alloc] init];
    label.numberOfLines = 0;
    
    label.text = @"利用layoutBlock可以自定义浮层的布局，注意此时contentViewMargins、maximumContentViewWidth属性均无效，如果需要实现外间距、最大宽高的保护，请自行计算。\n另外搭配showingAnimation、hidingAnimation也可制作自己的显示/隐藏动画，例如这个例子里实现了一个从底部升起的面板，升起后停靠在容器底端，你可以试着旋转设备，会发现依然能正确布局。";
    [contentView addSubview:label];
    
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn setBackgroundColor:[UIColor yellowColor]];
    [closeBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [contentView addSubview:closeBtn];
    closeBtn.frame = CGRectMake(0, 0, 50, 30);
    
    UIEdgeInsets contentViewPadding = UIEdgeInsetsMake(20, 20, 20, 20);
//    label.frame = CGRectMake(contentViewPadding.left, contentViewPadding.top, CGRectGetWidth(contentView.bounds) - UIEdgeInsetsGetHorizontalValue(contentViewPadding), QMUIViewSelfSizingHeight);
    
    contentView.contentSize = CGSizeMake(CGRectGetWidth(contentView.bounds), CGRectGetMaxY(label.frame) + contentViewPadding.bottom);
    
    DEDialogController *modalViewController = [[DEDialogController alloc] init];
    modalViewController.contentView = contentView;
    [closeBtn addTarget:modalViewController action:@selector(handleDimmingViewTapGestureRecognizer:) forControlEvents:UIControlEventTouchUpInside];
    modalViewController.layoutBlock = ^(CGRect containerBounds, CGFloat keyboardHeight, CGRect contentViewDefaultFrame) {
//        contentView.qmui_frameApplyTransform = CGRectSetXY(contentView.frame, CGFloatGetCenter(CGRectGetWidth(containerBounds), CGRectGetWidth(contentView.frame)), CGRectGetHeight(containerBounds) - 20 - CGRectGetHeight(contentView.frame));
        containerBounds.origin.y += 200;
        containerBounds.size.height -= 200;
        contentView.frameApplyTransform = containerBounds;
    };
    [modalViewController showWithAnimated:YES completion:nil];
}

@end
